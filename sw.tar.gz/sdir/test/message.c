#include "../hedley.h"

HEDLEY_MESSAGE("Hello, world!")

int main (void) {
  return 0;
}
